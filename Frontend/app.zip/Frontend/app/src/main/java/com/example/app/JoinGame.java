package com.example.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class JoinGame extends Activity {
    Button btnESC;
    Button btnJoin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_join_game);

        btnESC = (Button) findViewById(R.id.joinGame_ESC);
        btnJoin = (Button) findViewById(R.id.joinGame_join);


        btnJoin.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), Lobby.class); //change to lobby
            startActivity(intent);
        });

        //ESC BUTTON
        btnESC.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), Dashboard.class);
            startActivity(intent);
        });
    }
}