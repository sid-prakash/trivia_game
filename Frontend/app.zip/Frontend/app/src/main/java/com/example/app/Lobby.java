package com.example.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class Lobby extends Activity {
    Button btnESC;
    Button btnStartTrivia;

    Question questions[] = {
            new MCQuestion("How many sides does a triangle have?", "8", "6", "4", "3", 4),
            new MCQuestion("How many sides does a square have?", "8", "6", "4", "3", 3),
            new MCQuestion("How many sides does a hexagon have?", "8", "6", "4", "3", 2),
            new MCQuestion("How many sides does a octagon have?", "8", "6", "4", "3", 1)
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lobby);

        btnStartTrivia = findViewById(R.id.lobby_startTrivia);
        btnESC = findViewById(R.id.lobby_ESC);

        //START TRIVIA (ONLY HOST can see this button)
        btnStartTrivia.setOnClickListener(view -> {
            Intent intent = questions[0].prepareActivity(getApplicationContext());//I'm assuming a non-empty list of questions
            intent.putExtra("triviaQ", questions);
            intent.putExtra("currentQ", 0);
            intent.putExtra("score", 0);
            startActivity(intent);
        });

        //ESC BUTTON
        btnESC.setOnClickListener(view -> {
            //if the host presses 'ESE' then everyone is kicked to the dashboard
            Intent intent = new Intent(getApplicationContext(), Dashboard.class);
            startActivity(intent);
        });
    }
}