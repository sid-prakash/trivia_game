package com.example.app;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toast;
import android.util.Log;

import com.android.volley.AuthFailureError;
import com.android.volley.Request.Method;
import com.android.volley.RequestQueue;
import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class AddFriend extends Activity {
    Button btnAddFriendSearch;
    Button btnAddFriendESC;
    String userInput;
    //EditText displayCurrentFriends;
    private TextView msgResponse;
    private TextView msgResponse2;

    // These tags will be used to cancel the requests
    private String tag_json_obj = "jobj_req", tag_json_arry = "jarray_req";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_friend);

        btnAddFriendESC = (Button) findViewById(R.id.addFriend_ESC);
        btnAddFriendSearch = (Button) findViewById(R.id.addFriend_search);
        //displayCurrentFriends = (EditText) findViewById(R.id.addFriend_currentFriendsDisplay);
        //testing
        msgResponse = (TextView) findViewById((R.id.addFriend_currentFriendsDisplay));
        msgResponse2 = (TextView) findViewById((R.id.addFriends_friendRequestDisplay));



//        //ADD FRIEND BUTTON
//        btnAddFriendSearch.setOnClickListener(view -> {
//            //make volley call to backend of custom url
//            //Log.v("EditText", displayCurrentFriends.getText().toString());
//            String userInput = AddFriend.getText().toString();
//            Log.v("EditText", msgResponse.getText().toString());
//            Log.i("Test", "Add Friend Button Clicked");
//            msgResponse.setText(msgResponse.toString());
//            addFriendReq();
//        });

        //ADD FRIEND BUTTON
        btnAddFriendSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //make volley call to backend of custom url
                //addFriendReq();

                //Log.v("EditText", displayCurrentFriends.getText().toString());
                //String userInput = AddFriend.getText().toString();
                Log.v("EditText", msgResponse.getText().toString());
                Log.i("Test", "Add Friend Button Clicked");
                msgResponse.setText(msgResponse.toString());
            }
        });

        //ESC BUTTON
        btnAddFriendESC.setOnClickListener(view -> {
            Intent toDashboard = new Intent(getApplicationContext(), Dashboard.class);
            startActivity(toDashboard);
        });


        //Calls endpoint /friends/{userID}
        //makeJsonObjReq -> addFriendReq

        //NEED TO CONVERT THIS FOR AN ARRAY
//        private void addFriendReq () {
//            //showProgressDialog();
//            Log.i("Test", "json");
//
//            JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET,
//                    "https://coms-309-054.class.las.iastate.edu:8080/friends/1",
//                    null,
//                    new Response.Listener<JSONObject>() {
//                        @Override
//                        public void onResponse(JSONObject response) {
//                            Log.i("Test", "response");
//                            msgResponse.setText(response.toString());
//                            Toast.makeText(AddFriend.this, "Listing Friends", Toast.LENGTH_LONG).show();
//                        }
//                    }, new Response.ErrorListener() {
//                @Override
//                public void onErrorResponse(VolleyError error) {
//                    Log.i("Test", "response2");
//                    msgResponse.setText(error.toString());
//                    Toast.makeText(AddFriend.this, "Json Object Requested Failed!", Toast.LENGTH_LONG).show();
//                    //VolleyLog.d(TAG, "Error: " + error.getMessage());
//                }
//            }) {
//
//                /**
//                 * Passing some request headers
//                 */
//                @Override
//                public Map<String, String> getHeaders() throws AuthFailureError {
//                    HashMap<String, String> headers = new HashMap<String, String>();
//                    headers.put("Content-Type", "application/json");
//                    return headers;
//                }
//
//                @Override
//                protected Map<String, String> getParams() {
//                    Map<String, String> params = new HashMap<String, String>();
//                    params.put("id", "1");
//                    params.put("username", "Mason");
//                    params.put("displayname", "Mason");
//                    params.put("password", "pass");
//                    params.put("highScore", "0");
//                    params.put("isActive", "false");
//
//                    return params;
//                }   //this is the area where we parse the data from backend
//
//            };
//
//            // Adding request to request queue
//            AppController.getInstance().addToRequestQueue(jsonObjectRequest);
//        }
    }
}
