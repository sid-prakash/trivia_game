package com.example.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class HostGame extends Activity {
    Button btnESC;
    Button btnCreateLobby;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_host_game);

        btnCreateLobby = findViewById(R.id.hostGame_createLobby);
        btnESC = findViewById(R.id.hostLobby_ESC);

        //HOST LOBBY BUTTON
        btnCreateLobby.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), Lobby.class);
            startActivity(intent);
        });

        //ESC BUTTON
        btnESC.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), Dashboard.class);
            startActivity(intent);
        });




    }
}