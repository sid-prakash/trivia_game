package com.example.app;

import android.net.Uri;

import java.io.Serializable;
import java.net.URISyntaxException;

public class User implements Serializable {
    private int id;     //unique
    private String userName;    //database name
    private String displayName; //user-defined name
    private String password;
    int highScore;
    Boolean isActive;


    //this should be populated when logged in
    public User(int id, String userName, String displayName, String password, int highScore, boolean isActive) {
        this.id = id;
        this.userName = userName;
        this.displayName = displayName;
        this.password = password;
        this.highScore = highScore;
        this.isActive = isActive;
    }


    /**
     * Websocket Stuff
     */
//    private void connectWebSocket() {
//        URI uri;
//        try {
//            uri = new URI(Const.URL_websocket_test);
//        } catch (URISyntaxException e)  {
//            e.printStackTrace();
//            return;
//        }
//    }


    //getter and setter methods
    public int getId() {
        return id;
    }
//    public int setId(String id)  {
//        this.id = id;
//    }

    public String getUserName() {
        return displayName;
    }
    public String setUserName(String userName)  {
        this.userName = userName;
    }

}
